Title: Champions League Results, Basketball Europe

URL Source: https://www.betexplorer.com/basketball/europe/champions-league/results/

Markdown Content:
[Betexplorer](https://www.betexplorer.com/)

# Verificação de idade obrigatória

 Você deve ter pelo menos 18 anos para acessar este site. Por favor, confirme sua idade para continuar. 

 Sim, confirmo que tenho 18 anos ou mais  Não, tenho menos de 18 anos 

18+ | Jogue com responsabilidade | Ministério da Fazenda adverte: Aposta não é investimento | Aplicam-se T&C

[](https://www.betexplorer.com/basketball/europe/champions-league/results/#0)

[Betexplorer](https://www.betexplorer.com/)
*   [](https://www.betexplorer.com/basketball/europe/champions-league/results/#search)
*   [](https://www.betexplorer.com/basketball/europe/champions-league/results/#selections)

[Login](https://www.betexplorer.com/basketball/europe/champions-league/results/#login)[Register](https://www.betexplorer.com/basketball/europe/champions-league/results/#registration)

Language

*   English
*   Italian
*   Portuguese (Brazil)

*   
    *   all sports

EN
*   English
*   Italian
*   Portuguese (Brazil)

*   [Login](https://www.betexplorer.com/basketball/europe/champions-league/results/#login)
*   [Register](https://www.betexplorer.com/basketball/europe/champions-league/results/#registration)

*   [Football](https://www.betexplorer.com/)
*   [Basketball](https://www.betexplorer.com/basketball/)
*   [Hockey](https://www.betexplorer.com/hockey/)
*   [Tennis](https://www.betexplorer.com/tennis/)
*   [Baseball](https://www.betexplorer.com/baseball/)
*   [Volleyball](https://www.betexplorer.com/volleyball/)
*   [Handball](https://www.betexplorer.com/handball/)
*   [Betting](https://www.betexplorer.com/reviews/)

*   [Summary](https://www.betexplorer.com/basketball/)
*   [Matches](https://www.betexplorer.com/basketball/next/)
*   [Match Filter](https://www.betexplorer.com/basketball/odds-filter/)
*   [Streaks](https://www.betexplorer.com/basketball/streaks/wins/)
*   [Popular Bets](https://www.betexplorer.com/basketball/popular-bets/)
*   [Results](https://www.betexplorer.com/basketball/results/)
*   [Dropping Odds](https://www.betexplorer.com/basketball/dropping-odds/)
*   [My Selections](https://www.betexplorer.com/my/)

[](https://mediaserver.betmgmpartners.com/renderBanner.do?zoneId=1730680)

[](javascript:void(0);)

[Get Up To $250 Back in Bonus Bets Get! BetMGM.us](https://mediaserver.betmgmpartners.com/renderBanner.do?zoneId=1730680)

 Gambling problem? Call 1-800-GAMBLER or 1-800-MY-RESET (Available in the US) 877-8-HOPENY or text HOPENY (467369) (NY) 1-800-327-5050 (MA), 1-800-BETS-OFF (IA), 1-800-981-0023 (PR) 21+ only. Please Gamble Responsibly. See BetMGM.com for Terms. First Bet Offer for new customers only (if applicable). Subject to eligibility requirements. Bonus bets are non-withdrawable. In partnership with Kansas Crossing Casino and Hotel. Promotional offers not available in Mississippi, New York, Ontario, or Puerto Rico. 

[](javascript:void(0);)

[](https://www.bet365.com/hub/aff/open-account?affiliate=365_03996933)

[](javascript:void(0);)

[Bet $10 Get $200 Win or Lose Get! bet365.us](https://www.bet365.com/hub/aff/open-account?affiliate=365_03996933)

 Whatever the moment. It's Never Ordinary at bet365. That's why if you sign up now you will receive $200 in Bonus Bets Win or Lose when you bet $5! Minimum $10 deposit required. Minimum odds -500 or greater. Bonus Bets wager excluded from returns. New customers only. T&CS, time limits and exclusions apply. 

[](javascript:void(0);)

[](https://coinsaffs.com/dfd2ace5b)

[](javascript:void(0);)

[$1000 First Deposit Bonus Get! Coins.game](https://coinsaffs.com/dfd2ace5b)

 If you make a deposit but don't select the bonus, you can still activate it later. However, the next stage will not open until the current bonus is used. The bonus is available to new users for the first 8 days after registration only. Full T&Cs at coins.game 

[](javascript:void(0);)

*   [Home](https://www.betexplorer.com/)
*   [Basketball](https://www.betexplorer.com/basketball/)
*   [Europe](https://www.betexplorer.com/basketball/europe/)
*   Champions League 2026/2027

![Image 1: Europe](https://cci.betexplorer.com/6.svg)
# Champions League 2026/2027 Results

*   2026/2027

*   [Summary](https://www.betexplorer.com/basketball/europe/champions-league/)
*   [Results](https://www.betexplorer.com/basketball/europe/champions-league/results/)
*   [Fixtures](https://www.betexplorer.com/basketball/europe/champions-league/fixtures/)
*   [Stats](https://www.betexplorer.com/basketball/europe/champions-league/stats/)
*   [Head-to-head H2H](https://www.betexplorer.com/basketball/europe/champions-league/mutual-matches/)

*   [Main](https://www.betexplorer.com/basketball/europe/champions-league/results/?stage=007IAG8k "Main season game statistics")
*   [Qualification 1](https://www.betexplorer.com/basketball/europe/champions-league/results/?stage=tGQoGxoS)
*   [Qualification 2](https://www.betexplorer.com/basketball/europe/champions-league/results/?stage=zLYrZmTj)

*   Sort by:
*   
    *   date

| Group E | 1 | 2 |  |
| --- | --- | --- | --- |
| [**Unicaja** - Pardubice](https://www.betexplorer.com/basketball/europe/champions-league/unicaja-pardubice/0fftY2dJ/) | [94:66](https://www.betexplorer.com/basketball/europe/champions-league/unicaja-pardubice/0fftY2dJ/) | 1.01 | 15.50 | Yesterday |
| Group C | 1 | 2 |  |
| [**AEK Athens** - Szombathely](https://www.betexplorer.com/basketball/europe/champions-league/aek-athens-szombathely/Iy2adIwo/) | [90:89](https://www.betexplorer.com/basketball/europe/champions-league/aek-athens-szombathely/Iy2adIwo/) | 1.55 | 2.37 | Yesterday |
| Group B | 1 | 2 |  |
| [**Cibona** - Strasbourg](https://www.betexplorer.com/basketball/europe/champions-league/cibona-strasbourg/0xDL30oB/) | [101:79](https://www.betexplorer.com/basketball/europe/champions-league/cibona-strasbourg/0xDL30oB/) | 2.28 | 1.58 | Yesterday |
| [**Galatasaray** - Legia](https://www.betexplorer.com/basketball/europe/champions-league/galatasaray-sk-legia-warszawa/Esx1vpIa/) | [88:81](https://www.betexplorer.com/basketball/europe/champions-league/galatasaray-sk-legia-warszawa/Esx1vpIa/) | 1.14 | 5.53 | Yesterday |
| Group H | 1 | 2 |  |
| [Bnei Herzliya - **Bonn**](https://www.betexplorer.com/basketball/europe/champions-league/bnei-herzliya-bonn/Y13wHPwI/) | [79:85](https://www.betexplorer.com/basketball/europe/champions-league/bnei-herzliya-bonn/Y13wHPwI/) | 3.07 | 1.34 | 17.11. |
| [**Joventut Badalona** - FC Porto](https://www.betexplorer.com/basketball/europe/champions-league/joventut-badalona-fc-porto/Qy0VIo95/) | [74:70](https://www.betexplorer.com/basketball/europe/champions-league/joventut-badalona-fc-porto/Qy0VIo95/) | 1.04 | 10.03 | 17.11. |
| Group E | 1 | 2 |  |
| [Juventus - **Reggiana**](https://www.betexplorer.com/basketball/europe/champions-league/juventus-reggiana/A7xMpttP/) | [95:102](https://www.betexplorer.com/basketball/europe/champions-league/juventus-reggiana/A7xMpttP/) | 1.88 | 1.85 | 17.11. |
| Group C | 1 | 2 |  |
| [Antwerp Giants - Salon Vilpas](https://www.betexplorer.com/basketball/europe/champions-league/antwerp-giants-salon-vilpas/MofErzEa/) | [95:104 AET](https://www.betexplorer.com/basketball/europe/champions-league/antwerp-giants-salon-vilpas/MofErzEa/) | 1.16 | 4.78 | 17.11. |
|  |
| Group G | 1 | 2 |  |
| [Slavia Prague ERA NBK - **Igokea**](https://www.betexplorer.com/basketball/europe/champions-league/slavia-prague-era-nbk-igokea/AREca0CF/) | [81:89](https://www.betexplorer.com/basketball/europe/champions-league/slavia-prague-era-nbk-igokea/AREca0CF/) | 1.38 | 2.92 | 11.11. |
| Group D | 1 | 2 |  |
| [**Murcia** - Bamberg](https://www.betexplorer.com/basketball/europe/champions-league/murcia-bamberg-baskets/b9C5CUTr/) | [98:66](https://www.betexplorer.com/basketball/europe/champions-league/murcia-bamberg-baskets/b9C5CUTr/) | 1.05 | 8.52 | 11.11. |
| [**Peristeri** - Varese](https://www.betexplorer.com/basketball/europe/champions-league/peristeri-varese/vmEL8nT7/) | [101:96](https://www.betexplorer.com/basketball/europe/champions-league/peristeri-varese/vmEL8nT7/) | 1.81 | 1.93 | 11.11. |
| Group A | 1 | 2 |  |
| [**Rytas** - Nanterre](https://www.betexplorer.com/basketball/europe/champions-league/bc-rytas-nanterre/nHiHRoHd/) | [102:82](https://www.betexplorer.com/basketball/europe/champions-league/bc-rytas-nanterre/nHiHRoHd/) | 1.43 | 2.72 | 11.11. |
| Group G | 1 | 2 |  |
| [**Bilbao** - Alba Berlin](https://www.betexplorer.com/basketball/europe/champions-league/bilbao-alba-berlin/O8iAQxBE/) | [83:75](https://www.betexplorer.com/basketball/europe/champions-league/bilbao-alba-berlin/O8iAQxBE/) | 1.31 | 3.33 | 10.11. |
| Group F | 1 | 2 |  |
| [Hapoel Holon - **Vechta**](https://www.betexplorer.com/basketball/europe/champions-league/hapoel-holon-vechta/IVEtUza6/) | [85:90](https://www.betexplorer.com/basketball/europe/champions-league/hapoel-holon-vechta/IVEtUza6/) | 2.51 | 1.50 | 10.11. |
| [**Spartak Subotica** - Cholet](https://www.betexplorer.com/basketball/europe/champions-league/spartak-subotica-cholet/A7O3wJkd/) | [75:73](https://www.betexplorer.com/basketball/europe/champions-league/spartak-subotica-cholet/A7O3wJkd/) | 1.60 | 2.27 | 10.11. |
| Group A | 1 | 2 |  |
| [**Sabah BC** - Trabzonspor](https://www.betexplorer.com/basketball/europe/champions-league/sabah-bc-trabzonspor/f1DJvgCr/) | [91:72](https://www.betexplorer.com/basketball/europe/champions-league/sabah-bc-trabzonspor/f1DJvgCr/) | 2.52 | 1.49 | 10.11. |
|  |
| Group H | 1 | 2 |  |
| [**Bonn** - Bnei Herzliya](https://www.betexplorer.com/basketball/europe/champions-league/bonn-bnei-herzliya/Y1qdHYX0/) | [101:89](https://www.betexplorer.com/basketball/europe/champions-league/bonn-bnei-herzliya/Y1qdHYX0/) | 1.25 | 3.80 | 04.11. |
| Group C | 1 | 2 |  |
| [Szombathely - **AEK Athens**](https://www.betexplorer.com/basketball/europe/champions-league/szombathely-aek-athens/IehgIa04/) | [66:72](https://www.betexplorer.com/basketball/europe/champions-league/szombathely-aek-athens/IehgIa04/) | 1.62 | 2.22 | 04.11. |
| Group B | 1 | 2 |  |
| [**Legia** - Galatasaray](https://www.betexplorer.com/basketball/europe/champions-league/sk-legia-warszawa-galatasaray/jPUuiN15/) | [79:72](https://www.betexplorer.com/basketball/europe/champions-league/sk-legia-warszawa-galatasaray/jPUuiN15/) | 3.78 | 1.25 | 04.11. |
| Group H | 1 | 2 |  |
| [FC Porto - **Joventut Badalona**](https://www.betexplorer.com/basketball/europe/champions-league/fc-porto-joventut-badalona/MacAVOhB/) | [64:81](https://www.betexplorer.com/basketball/europe/champions-league/fc-porto-joventut-badalona/MacAVOhB/) | 3.62 | 1.26 | 03.11. |
| Group E | 1 | 2 |  |
| [Juventus - Pardubice](https://www.betexplorer.com/basketball/europe/champions-league/juventus-pardubice/tjaTlhht/) | [98:95 AET](https://www.betexplorer.com/basketball/europe/champions-league/juventus-pardubice/tjaTlhht/) | 1.30 | 3.35 | 03.11. |
| [**Unicaja** - Reggiana](https://www.betexplorer.com/basketball/europe/champions-league/unicaja-reggiana/KGhQyocf/) | [99:94](https://www.betexplorer.com/basketball/europe/champions-league/unicaja-reggiana/KGhQyocf/) | 1.05 | 9.10 | 03.11. |
| Group C | 1 | 2 |  |
| [**Salon Vilpas** - Antwerp Giants](https://www.betexplorer.com/basketball/europe/champions-league/salon-vilpas-antwerp-giants/WCigeDc5/) | [77:69](https://www.betexplorer.com/basketball/europe/champions-league/salon-vilpas-antwerp-giants/WCigeDc5/) | 6.17 | 1.11 | 03.11. |
| Group B | 1 | 2 |  |
| [**Strasbourg** - Cibona](https://www.betexplorer.com/basketball/europe/champions-league/strasbourg-cibona/raRXhqXh/) | [95:70](https://www.betexplorer.com/basketball/europe/champions-league/strasbourg-cibona/raRXhqXh/) | 1.20 | 4.57 | 03.11. |
| Group G | 1 | 2 |  |
| [**Alba Berlin** - Bilbao](https://www.betexplorer.com/basketball/europe/champions-league/alba-berlin-bilbao/nRbVDaR8/) | [103:100](https://www.betexplorer.com/basketball/europe/champions-league/alba-berlin-bilbao/nRbVDaR8/) | 1.59 | 2.28 | 28.10. |
| Group F | 1 | 2 |  |
| [Cholet - **Spartak Subotica**](https://www.betexplorer.com/basketball/europe/champions-league/cholet-spartak-subotica/SKvQp1cM/) | [65:69](https://www.betexplorer.com/basketball/europe/champions-league/cholet-spartak-subotica/SKvQp1cM/) | 1.27 | 3.60 | 28.10. |
| [Vechta - **Hapoel Holon**](https://www.betexplorer.com/basketball/europe/champions-league/vechta-hapoel-holon/CYBYVdUg/) | [81:88](https://www.betexplorer.com/basketball/europe/champions-league/vechta-hapoel-holon/CYBYVdUg/) | 1.87 | 1.87 | 28.10. |
| Group A | 1 | 2 |  |
| [**Rytas** - Trabzonspor](https://www.betexplorer.com/basketball/europe/champions-league/bc-rytas-trabzonspor/Yoq8Xy5F/) | [97:81](https://www.betexplorer.com/basketball/europe/champions-league/bc-rytas-trabzonspor/Yoq8Xy5F/) | 1.89 | 1.85 | 28.10. |
| Group G | 1 | 2 |  |
| [**Igokea** - Slavia Prague ERA NBK](https://www.betexplorer.com/basketball/europe/champions-league/igokea-slavia-prague-era-nbk/fi2wCwdL/) | [77:72](https://www.betexplorer.com/basketball/europe/champions-league/igokea-slavia-prague-era-nbk/fi2wCwdL/) | 1.57 | 2.33 | 27.10. |
| Group D | 1 | 2 |  |
| [Bamberg - **Varese**](https://www.betexplorer.com/basketball/europe/champions-league/bamberg-baskets-varese/CjkIw7Ss/) | [61:95](https://www.betexplorer.com/basketball/europe/champions-league/bamberg-baskets-varese/CjkIw7Ss/) | 1.76 | 1.98 | 27.10. |
| [Murcia - **Peristeri**](https://www.betexplorer.com/basketball/europe/champions-league/murcia-peristeri/t6iQWbFc/) | [72:80](https://www.betexplorer.com/basketball/europe/champions-league/murcia-peristeri/t6iQWbFc/) | 1.09 | 6.92 | 27.10. |
| Group A | 1 | 2 |  |
| [**Sabah BC** - Nanterre](https://www.betexplorer.com/basketball/europe/champions-league/sabah-bc-nanterre/bVRmpFlL/) | [87:80](https://www.betexplorer.com/basketball/europe/champions-league/sabah-bc-nanterre/bVRmpFlL/) | 2.65 | 1.44 | 27.10. |
| Group H | 1 | 2 |  |
| [Bnei Herzliya - **FC Porto**](https://www.betexplorer.com/basketball/europe/champions-league/bnei-herzliya-fc-porto/dvseZ6gn/) | [74:86](https://www.betexplorer.com/basketball/europe/champions-league/bnei-herzliya-fc-porto/dvseZ6gn/) | 1.54 | 2.40 | 21.10. |
| [**Joventut Badalona** - Bonn](https://www.betexplorer.com/basketball/europe/champions-league/joventut-badalona-bonn/673FMT9t/) | [76:74](https://www.betexplorer.com/basketball/europe/champions-league/joventut-badalona-bonn/673FMT9t/) | 1.15 | 4.90 | 21.10. |
| Group E | 1 | 2 |  |
| [Reggiana - **Juventus**](https://www.betexplorer.com/basketball/europe/champions-league/reggiana-juventus/M3XcjpCm/) | [75:76](https://www.betexplorer.com/basketball/europe/champions-league/reggiana-juventus/M3XcjpCm/) | 1.26 | 3.68 | 21.10. |
| Group C | 1 | 2 |  |
| [AEK Athens - **Antwerp Giants**](https://www.betexplorer.com/basketball/europe/champions-league/aek-athens-antwerp-giants/AVloKLVi/) | [76:103](https://www.betexplorer.com/basketball/europe/champions-league/aek-athens-antwerp-giants/AVloKLVi/) | 1.39 | 2.85 | 21.10. |
| Group E | 1 | 2 |  |
| [Pardubice - **Unicaja**](https://www.betexplorer.com/basketball/europe/champions-league/pardubice-unicaja/lG2ymWMh/) | [63:79](https://www.betexplorer.com/basketball/europe/champions-league/pardubice-unicaja/lG2ymWMh/) | 13.00 | 1.02 | 20.10. |
| Group C | 1 | 2 |  |
| [**Szombathely** - Salon Vilpas](https://www.betexplorer.com/basketball/europe/champions-league/szombathely-salon-vilpas/QFlocZSh/) | [85:72](https://www.betexplorer.com/basketball/europe/champions-league/szombathely-salon-vilpas/QFlocZSh/) | 1.29 | 3.43 | 20.10. |
| Group B | 1 | 2 |  |
| [Cibona - **Legia**](https://www.betexplorer.com/basketball/europe/champions-league/cibona-sk-legia-warszawa/ngBT1vGN/) | [77:95](https://www.betexplorer.com/basketball/europe/champions-league/cibona-sk-legia-warszawa/ngBT1vGN/) | 1.38 | 2.88 | 20.10. |
| [**Galatasaray** - Strasbourg](https://www.betexplorer.com/basketball/europe/champions-league/galatasaray-strasbourg/6HYht6mm/) | [83:77](https://www.betexplorer.com/basketball/europe/champions-league/galatasaray-strasbourg/6HYht6mm/) | 1.17 | 4.63 | 20.10. |
| Group G | 1 | 2 |  |
| [**Bilbao** - Slavia Prague ERA NBK](https://www.betexplorer.com/basketball/europe/champions-league/bilbao-slavia-prague-era-nbk/WE4O2ZI7/) | [97:86](https://www.betexplorer.com/basketball/europe/champions-league/bilbao-slavia-prague-era-nbk/WE4O2ZI7/) | 1.07 | 7.75 | 14.10. |
| Group F | 1 | 2 |  |
| [**Cholet** - Vechta](https://www.betexplorer.com/basketball/europe/champions-league/cholet-vechta/488QXIas/) | [84:66](https://www.betexplorer.com/basketball/europe/champions-league/cholet-vechta/488QXIas/) | 1.12 | 5.75 | 14.10. |
| [Spartak Subotica - **Hapoel Holon**](https://www.betexplorer.com/basketball/europe/champions-league/spartak-subotica-hapoel-holon/OjQeuuLq/) | [84:86](https://www.betexplorer.com/basketball/europe/champions-league/spartak-subotica-hapoel-holon/OjQeuuLq/) | 1.40 | 2.80 | 14.10. |
| Group D | 1 | 2 |  |
| [Bamberg - **Murcia**](https://www.betexplorer.com/basketball/europe/champions-league/bamberg-baskets-murcia/OC11LPCD/) | [67:86](https://www.betexplorer.com/basketball/europe/champions-league/bamberg-baskets-murcia/OC11LPCD/) | 3.25 | 1.31 | 14.10. |
| Group A | 1 | 2 |  |
| [**Trabzonspor** - Sabah BC](https://www.betexplorer.com/basketball/europe/champions-league/trabzonspor-sabah-bc/0I6LbE3E/) | [100:83](https://www.betexplorer.com/basketball/europe/champions-league/trabzonspor-sabah-bc/0I6LbE3E/) | 1.07 | 7.58 | 14.10. |
| Group G | 1 | 2 |  |
| [**Alba Berlin** - Igokea](https://www.betexplorer.com/basketball/europe/champions-league/alba-berlin-igokea/KK6qjdZ1/) | [90:79](https://www.betexplorer.com/basketball/europe/champions-league/alba-berlin-igokea/KK6qjdZ1/) | 1.18 | 4.60 | 13.10. |
| Group D | 1 | 2 |  |
| [Varese - **Peristeri**](https://www.betexplorer.com/basketball/europe/champions-league/varese-peristeri/8MfoP7Dl/) | [82:85](https://www.betexplorer.com/basketball/europe/champions-league/varese-peristeri/8MfoP7Dl/) | 1.40 | 2.80 | 13.10. |
| Group A | 1 | 2 |  |
| [**Nanterre** - Rytas](https://www.betexplorer.com/basketball/europe/champions-league/nanterre-bc-rytas/tCnGVFZR/) | [93:65](https://www.betexplorer.com/basketball/europe/champions-league/nanterre-bc-rytas/tCnGVFZR/) | 1.47 | 2.60 | 13.10. |
| Group H | 1 | 2 |  |
| [**Bonn** - FC Porto](https://www.betexplorer.com/basketball/europe/champions-league/bonn-fc-porto/tSn4FC2D/) | [78:74](https://www.betexplorer.com/basketball/europe/champions-league/bonn-fc-porto/tSn4FC2D/) | 1.21 | 4.17 | 07.10. |
| Group G | 1 | 2 |  |
| [Slavia Prague ERA NBK - **Alba Berlin**](https://www.betexplorer.com/basketball/europe/champions-league/slavia-prague-era-nbk-alba-berlin/xEGk1Ms3/) | [86:110](https://www.betexplorer.com/basketball/europe/champions-league/slavia-prague-era-nbk-alba-berlin/xEGk1Ms3/) | 1.98 | 1.76 | 07.10. |
| Group F | 1 | 2 |  |
| [**Spartak Subotica** - Vechta](https://www.betexplorer.com/basketball/europe/champions-league/spartak-subotica-vechta/8xNfwuxK/) | [96:64](https://www.betexplorer.com/basketball/europe/champions-league/spartak-subotica-vechta/8xNfwuxK/) | 1.29 | 3.45 | 07.10. |
| Group E | 1 | 2 |  |
| [Juventus - **Unicaja**](https://www.betexplorer.com/basketball/europe/champions-league/juventus-unicaja/xfvEn2BC/) | [66:105](https://www.betexplorer.com/basketball/europe/champions-league/juventus-unicaja/xfvEn2BC/) | 3.92 | 1.23 | 07.10. |
| Group D | 1 | 2 |  |
| [**Murcia** - Varese](https://www.betexplorer.com/basketball/europe/champions-league/murcia-varese/EJkYUxpA/) | [85:58](https://www.betexplorer.com/basketball/europe/champions-league/murcia-varese/EJkYUxpA/) | 1.11 | 6.10 | 07.10. |
| Group C | 1 | 2 |  |
| [**AEK Athens** - Salon Vilpas](https://www.betexplorer.com/basketball/europe/champions-league/aek-athens-salon-vilpas/Ikowaebt/) | [95:93](https://www.betexplorer.com/basketball/europe/champions-league/aek-athens-salon-vilpas/Ikowaebt/) | 1.04 | 9.07 | 07.10. |
| [**Antwerp Giants** - Szombathely](https://www.betexplorer.com/basketball/europe/champions-league/antwerp-giants-szombathely/Eaav9eNj/) | [99:93](https://www.betexplorer.com/basketball/europe/champions-league/antwerp-giants-szombathely/Eaav9eNj/) | 1.57 | 2.31 | 07.10. |
| Group A | 1 | 2 |  |
| [Trabzonspor - Nanterre](https://www.betexplorer.com/basketball/europe/champions-league/trabzonspor-nanterre/8OJZzBB7/) | [93:83 AET](https://www.betexplorer.com/basketball/europe/champions-league/trabzonspor-nanterre/8OJZzBB7/) | 1.30 | 3.43 | 07.10. |
| Group H | 1 | 2 |  |
| [**Joventut Badalona** - Bnei Herzliya](https://www.betexplorer.com/basketball/europe/champions-league/joventut-badalona-bnei-herzliya/vL1NK7vg/) | [86:75](https://www.betexplorer.com/basketball/europe/champions-league/joventut-badalona-bnei-herzliya/vL1NK7vg/) | 1.03 | 10.33 | 06.10. |
| Group G | 1 | 2 |  |
| [Igokea - **Bilbao**](https://www.betexplorer.com/basketball/europe/champions-league/igokea-bilbao/Ol1G4ele/) | [79:92](https://www.betexplorer.com/basketball/europe/champions-league/igokea-bilbao/Ol1G4ele/) | 2.04 | 1.73 | 06.10. |
| Group F | 1 | 2 |  |
| [Hapoel Holon - **Cholet**](https://www.betexplorer.com/basketball/europe/champions-league/hapoel-holon-cholet/KzoOQu6j/) | [79:99](https://www.betexplorer.com/basketball/europe/champions-league/hapoel-holon-cholet/KzoOQu6j/) | 2.92 | 1.38 | 06.10. |
| Group E | 1 | 2 |  |
| [**Reggiana** - Pardubice](https://www.betexplorer.com/basketball/europe/champions-league/reggiana-pardubice/UTz6lOt0/) | [82:65](https://www.betexplorer.com/basketball/europe/champions-league/reggiana-pardubice/UTz6lOt0/) | 1.16 | 4.83 | 06.10. |
| Group D | 1 | 2 |  |
| [**Peristeri** - Bamberg](https://www.betexplorer.com/basketball/europe/champions-league/peristeri-bamberg-baskets/6g67WkLE/) | [93:87](https://www.betexplorer.com/basketball/europe/champions-league/peristeri-bamberg-baskets/6g67WkLE/) | 1.66 | 2.13 | 06.10. |
| Group B | 1 | 2 |  |
| [**Cibona** - Galatasaray](https://www.betexplorer.com/basketball/europe/champions-league/cibona-galatasaray/SOED5MGb/) | [96:76](https://www.betexplorer.com/basketball/europe/champions-league/cibona-galatasaray/SOED5MGb/) | 3.75 | 1.25 | 06.10. |
| [**Strasbourg** - Legia](https://www.betexplorer.com/basketball/europe/champions-league/strasbourg-sk-legia-warszawa/AoTPf52t/) | [100:62](https://www.betexplorer.com/basketball/europe/champions-league/strasbourg-sk-legia-warszawa/AoTPf52t/) | 1.44 | 2.65 | 06.10. |
| Group A | 1 | 2 |  |
| [**Rytas** - Sabah BC](https://www.betexplorer.com/basketball/europe/champions-league/bc-rytas-sabah-bc/0Yp0Zcz3/) | [82:73](https://www.betexplorer.com/basketball/europe/champions-league/bc-rytas-sabah-bc/0Yp0Zcz3/) | 1.15 | 5.16 | 06.10. |

[![Image 2: OddsPortal.com](https://www.betexplorer.com/res/images/portal_op_logo.gif)](https://www.betexplorer.com/redirects/?url=https://www.oddsportal.com/)Betting odds service provided in cooperation with [OddsPortal.com](https://www.betexplorer.com/redirects/?url=https://www.oddsportal.com/)

**Help:** This page serves to display complete results for Champions League 2026/2027 which is sorted in basketball- Europe category. Make use of complete results list in Champions League 2026/2027 and utilize connection to archive betting odds. Click on match detail and find out result as well as 1X2, under/over, asian handicap and moneyline odds offered for the game played in Champions League 2026/2027.

My Selections (0)

**No bets selected** yet. To add a bet click the odds while browsing through BetExplorer!

Data by:

![Image 3: Opta](https://www.betexplorer.com/res/images/opta_logo.svg)

[![Image 4: GPWA](https://www.betexplorer.com/res/images/icon-gpwa.gif)](http://certify.gpwa.org/verify/betexplorer.com/)

*   [Terms of Use](https://www.betexplorer.com/terms-of-service.php)
*   [Privacy Policy](https://www.betexplorer.com/personal-data.php)
*   [GDPR and Journalism](https://www.betexplorer.com/gdpr-and-journalism.php)
*   [Site Info](https://www.betexplorer.com/site-info.php)
*   [Desktop version Mobile version](https://www.betexplorer.com/basketball/europe/champions-league/results/)
*   [Contact Us](https://www.betexplorer.com/contact.php)
*   Set privacy
*   [Impressum](https://www.betexplorer.com/impressum.php)

Copyright 2003-2026 by BetExplorer.com

Gamble Responsibly [Gambling Therapy](https://www.gamblingtherapy.org/). 18+

[![Image 5: Gamble Aware](https://www.betexplorer.com/res/images/gamble-aware.png)](https://www.begambleaware.org/)

![Image 6: 18+](https://www.betexplorer.com/res/images/18-plus.png)[![Image 7: Gamble Aware](https://www.betexplorer.com/res/images/gamble-aware.png)](https://www.begambleaware.org/)

 Please, gamble responsibly 

Confirm Cancel

Login

Show

Login[Lost Password?](https://www.betexplorer.com/basketball/europe/champions-league/results/#lostpass)

Not a member? [Register](https://www.betexplorer.com/basketball/europe/champions-league/results/#registration)

Lost password or activation code

If you have forgotten your username and/or password on BetExplorer.com, enter your e-mail address used in registration. Our system will send your password to your e-mail address. If you haven't activated your username on BetExplorer.com yet, there will be also your activation code sent.

Send password[Login](https://www.betexplorer.com/basketball/europe/champions-league/results/#login)

Not a member? [Register](https://www.betexplorer.com/basketball/europe/champions-league/results/#registration)

Account activation

Activate

Register for free

*    Follow your favourite leagues easier 
*    Save your time by setting your preferred sport 
*    See only your favourite bookmakers 

Show

Show

By clicking on “Register” button, you agree to the [Terms of Use](https://www.betexplorer.com/terms-of-service.php) and acknowledge our Privacy Policy on our website. 

Register

Already a member? [Log In](https://www.betexplorer.com/basketball/europe/champions-league/results/#login)

Close window

*   
    *   all sports

 All countries 

My Selections (0)

[Click to BET NOW ![Image 8: Redirect](https://www.betexplorer.com/res/images/icon_redirect.svg)](https://www.betexplorer.com/basketball/europe/champions-league/results/#)![Image 9: Close](https://www.betexplorer.com/res/images/icon_close_modal.svg)

Language
*   English
*   Italian
*   Portuguese (Brazil)

## We Care About Your Privacy

We and our 1016 partner(s) store and access personal data, like browsing data or unique identifiers, on your device. Selecting I Accept enables tracking technologies to support the purposes shown under we and our partners process data to provide. Selecting Reject All or withdrawing your consent will disable them. If trackers are disabled, some content and ads you see may not be as relevant to you. You can resurface this menu to change your choices or withdraw consent at any time by clicking the Manage Preferences link on the bottom of the webpage [or the floating icon on the bottom-left of the webpage, if applicable]. Your choices will have effect within our Website. For more details, refer to our Privacy Policy.[Third parties](https://www.flashscore.com/third-parties/)

### We and our partners process data to provide:

Use precise geolocation data. Actively scan device characteristics for identification. Store and/or access information on a device. Personalised advertising and content, advertising and content measurement, audience research and services development. [List of Partners (vendors)](https://www.betexplorer.com/basketball/europe/champions-league/results/#)

I Accept Reject All Manage Preferences

![Image 10: Company Logo](https://cdn.cookielaw.org/logos/static/ot_company_logo.png)

## About Your Privacy

## About Your Privacy

*   ### Your Privacy 
*   ### Strictly Necessary Cookies 
*   ### Performance Cookies 
*   ### Social Media Cookies 
*   ### Targeting Cookies 
*   ### Functional Cookies 
*   ### Store and/or access information on a device 844 partners can use this purpose 
*   ### Personalised advertising and content, advertising and content measurement, audience research and services development 986 partners can use this purpose 
*   ### Use precise geolocation data 285 partners can use this special feature 
*   ### Actively scan device characteristics for identification 162 partners can use this special feature 
*   ### Ensure security, prevent and detect fraud, and fix errors 651 partners can use this special purpose 
*   ### Deliver and present advertising and content 643 partners can use this special purpose 
*   ### Match and combine data from other data sources 468 partners can use this feature 
*   ### Link different devices 374 partners can use this feature 
*   ### Identify devices based on information transmitted automatically 589 partners can use this feature 
*   ### Save and communicate privacy choices 524 partners can use this special purpose 

#### Your Privacy

We process your data to deliver content or advertisements and measure the delivery of such content or advertisements to extract insights about our website. We share this information with our partners on the basis of consent and legitimate interest. You may exercise your right to consent or object to a legitimate interest, based on a specific purpose below or at a partner level in the link under each purpose. These choices will be signaled to our vendors participating in the Transparency and Consent Framework. The choices you make regarding the purposes and vendors listed in this notice are saved and stored locally on your device for a maximum duration of 1 year.   
[More information](https://cookiepedia.co.uk/giving-consent-to-cookies)[Third parties](https://www.flashscore.com/third-parties/)

**Timestamp:** --

_This User ID will be used as a unique identifier while storing and accessing your preferences for future._

**User ID:** 42d35e5f-b564-4d7b-b26d-0a6536b2952e

List of IAB Vendors

#### Strictly Necessary Cookies

Always Active

These cookies are necessary for the website to function and cannot be switched off in our systems. They are usually only set in response to actions made by you which amount to a request for services, such as setting your privacy preferences, logging in or filling in forms. You can set your browser to block or alert you about these cookies, but some parts of the site will not then work. These cookies do not store any personally identifiable information.

List of cookies

#### Performance Cookies

- [x] Performance Cookies 

These cookies allow us to count visits and traffic sources so we can measure and improve the performance of our site. They help us to know which pages are the most and least popular and see how visitors move around the site. If you do not allow these cookies we will not know when you have visited our site, and will not be able to monitor and improve its performance.

List of cookies

#### Social Media Cookies

- [x] Social Media Cookies 

These cookies are set by a range of social media services that we have added to the site to enable you to share our content with your friends and networks. They are capable of tracking your browser across other sites and building up a profile of your interests. This may impact the content and messages you see on other websites you visit. If you do not allow these cookies you may not be able to use or see these sharing tools.

List of cookies

#### Targeting Cookies

- [x] Targeting Cookies 

These cookies may be set through our site by our advertising partners. They may be used by those companies to build a profile of your interests and show you relevant adverts on other sites. They do not store directly personal information, but are based on uniquely identifying your browser and internet device. If you do not allow these cookies, you will experience less targeted advertising.

List of cookies

#### Functional Cookies

- [x] Functional Cookies 

These cookies enable the website to provide enhanced functionality and personalisation. They may be set by us or by third party providers whose services we have added to our pages. If you do not allow these cookies then some or all of these services may not function properly.

List of cookies

#### Store and/or access information on a device 844 partners can use this purpose

- [x] Store and/or access information on a device 

Cookies, device or similar online identifiers (e.g. login-based identifiers, randomly assigned identifiers, network based identifiers) together with other information (e.g. browser type and information, language, screen size, supported technologies etc.) can be stored or read on your device to recognise it each time it connects to an app or to a website, for one or several of the purposes presented here.

List of IAB Vendors|View Illustrations

#### Personalised advertising and content, advertising and content measurement, audience research and services development 986 partners can use this purpose

- [x] Personalised advertising and content, advertising and content measurement, audience research and services development 

*   ##### Use limited data to select advertising 788 partners can use this purpose

- [x] Switch Label   
Advertising presented to you on this service can be based on limited data, such as the website or app you are using, your non-precise location, your device type or which content you are (or have been) interacting with (for example, to limit the number of times an ad is presented to you).

View Illustrations Object to Legitimate Interests  Remove Objection  

*   ##### Create profiles for personalised advertising 637 partners can use this purpose

- [x] Switch Label   
Information about your activity on this service (such as forms you submit, content you look at) can be stored and combined with other information about you (for example, information from your previous activity on this service and other websites or apps) or similar users. This is then used to build or improve a profile about you (that might include possible interests and personal aspects). Your profile can be used (also later) to present advertising that appears more relevant based on your possible interests by this and other entities.

View Illustrations

*   ##### Use profiles to select personalised advertising 638 partners can use this purpose

- [x] Switch Label   
Advertising presented to you on this service can be based on your advertising profiles, which can reflect your activity on this service or other websites or apps (like the forms you submit, content you look at), possible interests and personal aspects.

View Illustrations

*   ##### Create profiles to personalise content 261 partners can use this purpose

- [x] Switch Label   
Information about your activity on this service (for instance, forms you submit, non-advertising content you look at) can be stored and combined with other information about you (such as your previous activity on this service or other websites or apps) or similar users. This is then used to build or improve a profile about you (which might for example include possible interests and personal aspects). Your profile can be used (also later) to present content that appears more relevant based on your possible interests, such as by adapting the order in which content is shown to you, so that it is even easier for you to find content that matches your interests.

View Illustrations

*   ##### Use profiles to select personalised content 234 partners can use this purpose

- [x] Switch Label   
Content presented to you on this service can be based on your content personalisation profiles, which can reflect your activity on this or other services (for instance, the forms you submit, content you look at), possible interests and personal aspects. This can for example be used to adapt the order in which content is shown to you, so that it is even easier for you to find (non-advertising) content that matches your interests.

View Illustrations

*   ##### Measure advertising performance 913 partners can use this purpose

- [x] Switch Label   
Information regarding which advertising is presented to you and how you interact with it can be used to determine how well an advert has worked for you or other users and whether the goals of the advertising were reached. For instance, whether you saw an ad, whether you clicked on it, whether it led you to buy a product or visit a website, etc. This is very helpful to understand the relevance of advertising campaigns.

View Illustrations Object to Legitimate Interests  Remove Objection  

*   ##### Measure content performance 396 partners can use this purpose

- [x] Switch Label   
Information regarding which content is presented to you and how you interact with it can be used to determine whether the (non-advertising) content e.g. reached its intended audience and matched your interests. For instance, whether you read an article, watch a video, listen to a podcast or look at a product description, how long you spent on this service and the web pages you visit etc. This is very helpful to understand the relevance of (non-advertising) content that is shown to you.

View Illustrations Object to Legitimate Interests  Remove Objection  

*   ##### Understand audiences through statistics or combinations of data from different sources 580 partners can use this purpose

- [x] Switch Label   
Reports can be generated based on the combination of data sets (like user profiles, statistics, market research, analytics data) regarding your interactions and those of other users with advertising or (non-advertising) content to identify common characteristics (for instance, to determine which target audiences are more receptive to an ad campaign or to certain contents).

View Illustrations Object to Legitimate Interests  Remove Objection  

*   ##### Develop and improve services 680 partners can use this purpose

- [x] Switch Label   
Information about your activity on this service, such as your interaction with ads or content, can be very helpful to improve products and services and to build new products and services based on user interactions, the type of audience, etc. This specific purpose does not include the development or improvement of user profiles and identifiers.

View Illustrations Object to Legitimate Interests  Remove Objection  

*   ##### Use limited data to select content 177 partners can use this purpose

- [x] Switch Label   
Content presented to you on this service can be based on limited data, such as the website or app you are using, your non-precise location, your device type, or which content you are (or have been) interacting with (for example, to limit the number of times a video or an article is presented to you).

View Illustrations Object to Legitimate Interests  Remove Objection  

List of IAB Vendors

#### Use precise geolocation data 285 partners can use this special feature

- [x] Use precise geolocation data 

With your acceptance, your precise location (within a radius of less than 500 metres) may be used in support of the purposes explained in this notice.

List of IAB Vendors

#### Actively scan device characteristics for identification 162 partners can use this special feature

- [x] Actively scan device characteristics for identification 

With your acceptance, certain characteristics specific to your device might be requested and used to distinguish it from other devices (such as the installed fonts or plugins, the resolution of your screen) in support of the purposes explained in this notice.

List of IAB Vendors

#### Ensure security, prevent and detect fraud, and fix errors 651 partners can use this special purpose

Always Active

Your data can be used to monitor for and prevent unusual and possibly fraudulent activity (for example, regarding advertising, ad clicks by bots), and ensure systems and processes work properly and securely. It can also be used to correct any problems you, the publisher or the advertiser may encounter in the delivery of content and ads and in your interaction with them.

List of IAB Vendors|View Illustrations

#### Deliver and present advertising and content 643 partners can use this special purpose

Always Active

Certain information (like an IP address or device capabilities) is used to ensure the technical compatibility of the content or advertising, and to facilitate the transmission of the content or ad to your device.

List of IAB Vendors|View Illustrations

#### Match and combine data from other data sources 468 partners can use this feature

Always Active

Information about your activity on this service may be matched and combined with other information relating to you and originating from various sources (for instance your activity on a separate online service, your use of a loyalty card in-store, or your answers to a survey), in support of the purposes explained in this notice.

List of IAB Vendors

#### Link different devices 374 partners can use this feature

Always Active

In support of the purposes explained in this notice, your device might be considered as likely linked to other devices that belong to you or your household (for instance because you are logged in to the same service on both your phone and your computer, or because you may use the same Internet connection on both devices).

List of IAB Vendors

#### Identify devices based on information transmitted automatically 589 partners can use this feature

Always Active

Your device might be distinguished from other devices based on information it automatically sends when accessing the Internet (for instance, the IP address of your Internet connection or the type of browser you are using) in support of the purposes exposed in this notice.

List of IAB Vendors

#### Save and communicate privacy choices 524 partners can use this special purpose

Always Active

The choices you make regarding the purposes and entities listed in this notice are saved and made available to those entities in the form of digital signals (such as a string of characters). This is necessary in order to enable both this service and those entities to respect such choices.

List of IAB Vendors|View Illustrations

### Vendors List

Consent Leg.Interest

- [x] checkbox label label

- [x] checkbox label label

- [x] checkbox label label

Clear
*   - [x] checkbox label label 

Apply Cancel

Confirm My Choices

Reject All Allow All

[![Image 11: Powered by Onetrust](https://cdn.cookielaw.org/logos/static/powered_by_logo.svg)](https://www.onetrust.com/solutions/consent-and-preferences/)
